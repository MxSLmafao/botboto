import { ApplyOptions } from "@sapphire/decorators";
import { Events, Listener } from "@sapphire/framework";
import DJS from "discord.js";

@ApplyOptions<Listener.Options>({
  event: Events.InteractionCreate,
  name: "Interaction Create",
})
export class InteractionCreateListener extends Listener {
  public async run(interaction: DJS.Interaction): Promise<void> {
    if (interaction.isButton()) {
      if (interaction.customId === "verificaus") {
        const verificacion = new DJS.EmbedBuilder()
          .setTitle(`Message to **${interaction.user.username}**`)
          .setDescription(
            "**Congratulations, it has been verified correctly, you will have your role!**"
          )
          .setColor("Green");
  
        interaction
          .reply({ embeds: [verificacion], ephemeral: true })
          .then((verificacion) => {
            (interaction as DJS.ButtonInteraction<"cached">).member.roles.add(
              process.env.ROLE_ID!
            );
          });
         }
    }
  }
}
