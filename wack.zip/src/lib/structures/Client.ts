import { SapphireClient } from '@sapphire/framework';
import { ActivityType } from 'discord.js';
import { connect } from 'mongoose';
import { join } from 'path';

export default class Bot extends SapphireClient {
  constructor() {    
    super({
      intents: ['Guilds', 'GuildMessages', 'MessageContent', 'GuildMembers', 'GuildMessageReactions'],
      presence: {
        status: 'dnd',
        activities: [
          {
            name: 'Development',
            type: ActivityType.Listening,
          },
        ],
      },
      baseUserDirectory: join(__dirname, '..', '..'),
    });    
  } 


  public async initialize() {
    await this.login();
    connect(process.env.MONGO_URI!).then(() =>
      this.logger.info('Connected to MongoDB!')
    );
  }
}
