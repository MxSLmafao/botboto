import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import users from '../../lib/models/users';
import { Colors, ComponentType, EmbedBuilder } from 'discord.js';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'unwarn',
  description: 'Delete a warning',
  requiredUserPermissions: ['Administrator'],
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addUserOption((option) =>
            option.setName('user').setDescription('The user').setRequired(true)
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

     // @ts-ignore
     if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
  
    try {
      const { options, guild } = interaction;

      const user = options.getUser('user')!;

      const data = await users.findOne({
        userId: user.id,
      });

      const userWarns = data?.moderations?.length
        ? data.moderations.filter((d) => d.type === 'Warning')
        : [];

      if (!userWarns.length)
        return interaction.followUp({
          content: `This user has no warnings`,
        });

        const embed = new EmbedBuilder()
        .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
        })
        .setTitle(`Select a Warning`)
        .setDescription(
          `Select a warning to unwarn ${user.username}`
        )
        .setColor(Colors.Yellow)
        .setTimestamp();

        const moderatorname = guild!.members.cache.get(userWarns[0].moderatorId)?.user.username

      const warn = await interaction.followUp({
        embeds: [embed],
        components: [
          {
            type: 1,
            components: [
              {
                type: 3,
                customId: 'delwarn',
                options: userWarns.map((d, i) => {
                    return {
                      label: `Warning ${i + 1}`,
                      value: `${i + 1}`,
                      description: `Reason: ${d.reason} || Moderator: ${moderatorname}`,
                    };
                  }

              ),
              },
            ],
          },
        ],
      });

      const filter = (i: any) => i.user.id === interaction.user.id;

      const collector = warn.createMessageComponentCollector({
        filter,
        time: 60000,
        componentType: ComponentType.StringSelect
      });

      collector.on('collect', async (i) => {
        const index = parseInt(i.values[0]) - 1;
        const warn = userWarns[index];

        const newData = data!.moderations.filter((d) => d.id !== warn.id);

        await users.updateOne(
          { userId: user.id },
          { $set: { moderations: newData } }
        );

        const embed = new EmbedBuilder()
        .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
        })
        .setTitle(`Warning deleted`)
        .setDescription(
          `Warning deleted from ${user.username}`
        )
        .setColor(Colors.Green)
        .setTimestamp();

        await i.update({
          embeds: [embed],
          components: [],
        });
      }
    );

      collector.on('end', async (i) => {
        if (i.size === 0) {
          const embed = new EmbedBuilder()
          .setAuthor({
            name: interaction.client.user!.username,
            iconURL: interaction.client.user!.displayAvatarURL(),
          })
          .setTitle(`Warning deleted`)
          .setDescription(
            `Warning deleted from ${user.username}`
          )
          .setColor(Colors.Green)
          .setTimestamp();

          await warn.edit({
            embeds: [embed],
            components: [],
          });
        }
      }
    );
    

    } catch (err) {
      return console.error(err);
    }
  }
}
