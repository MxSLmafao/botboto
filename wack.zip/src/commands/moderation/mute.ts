import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { Colors, ComponentType, EmbedBuilder, GuildMember } from 'discord.js';
import users from '../../lib/models/users';
import ms from 'ms';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'mute',
  description: 'Mute an user',
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addUserOption((option) =>
            option
              .setName('user')
              .setDescription('User to mute')
              .setRequired(true)
          )
          .addStringOption((option) =>
            option.setName('reason').setDescription('Reason of the kick')
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
    await interaction.deferReply({ ephemeral: true }).catch(() => {});

     // @ts-ignore
     if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
    let member = interaction.options.getMember('user')! as GuildMember;
    let reason = interaction.options.getString('reason')!;

    if (
      member.roles.highest.position >=
      (interaction.member! as GuildMember).roles.highest.position
    )
      return interaction.editReply(
        'You cannot mute a user with a hierarchy greater than or equal to yours'
      );

    if (
      member.roles.highest.position >=
        (
          interaction.guild!.members.cache.get(
            this.container.client.user!.id
          ) as GuildMember
        ).roles.highest.position ||
      !member.manageable
    )
      return interaction.editReply("I can't mute that member");

    const embed = new EmbedBuilder({
      author:{
        name: this.container.client.user.username,
        iconURL: this.container.client.user.displayAvatarURL()
      },
      title: `Mute ${member.user.username}`,
      description: `Please select a time to mute ${member.user.tag}`,
      timestamp: Date.now(),
      color: Colors.Yellow
    });

    const row = new DJS.ActionRowBuilder<DJS.StringSelectMenuBuilder>({
      components: [
        new DJS.StringSelectMenuBuilder({
          customId: 'temp:mute-time',
          placeholder: 'No time selected',
          max_values: 1,
          options: [
            {
              label: '60 seconds',
              value: '60000'
            },
            {
              label: '5 minutes',
              value: '300000'
            },
            {
              label: '10 minutes',
              value: '600000'
            },
            {
              label: '1 hour',
              value: '3600000'
            },
            {
              label: '1 day',
              value: '86400000'
            },
            {
              label: '1 week',
              value: '604800000'
            }
          ]
        })
      ]
    });

    const embed1 = new EmbedBuilder()
    .setTitle('Member muted')
    .setThumbnail(member.user.displayAvatarURL())
    .setDescription(
      `• Member: <@!${member.user.id}>\n• Muted by: <@!${
        interaction.user.id
      }>\n• Reason: ${reason || 'Unspecified'}`
    )
    .setColor(Colors.Blue);

    const prompt = await interaction.editReply({
      embeds: [embed],
      components: [row]
    });

    const filter = (i: DJS.SelectMenuInteraction) => i.user.id === interaction.user.id;

    const collector = prompt.createMessageComponentCollector({
      filter,
      time: 60000,
      componentType: ComponentType.StringSelect
    });

    collector.on('collect', async (i) => {
      const time = i.values[0];
      const duration = ms(time);

      const data = await users.findOne({
        userId: member.id
      });

      member.timeout(duration, reason).then(async () => {

        if (!data) {
          await users.create({
            userId: member.id,
            moderations: [
              {
                guildId: interaction.guildId,
                memberId: member.id,
                reason: reason || 'Unspecified',
                moderatorId: interaction.user.id,
                timestamp: Date.now(),
                type: 'Mute',
              },
            ],
          });
        } else {
          await users.updateOne(
            {
              userId: member.id,
            },
            {
              $push: {
                moderations: {
                    guildId: interaction.guildId,
                    memberId: member.id,
                    reason: reason || 'Unspecified',
                    moderatorId: interaction.user.id,
                    timestamp: Date.now(),
                    type: 'Mute',
                },
              }
            }
          )
        }
      });
      interaction.editReply({
        embeds: [embed1],
        components: []
      })
      interaction.followUp({
        content: "Timeout",
        ephemeral: true
      })
    });
    member.send({
      embeds: [
        new EmbedBuilder()
          .setAuthor({
            name: interaction.client.user!.username,
            iconURL: interaction.client.user!.displayAvatarURL(),
          })
          .setColor(Colors.Yellow)
          .setDescription(
            `You have been muted from ${interaction.guild!.name}\nReason: ${reason}`
          )
          .setTimestamp(),
      ],
    });
        collector.on('end', async (collected, reason) => {
          prompt.edit({
            embeds: [embed1],
            components: []
          })
    });
  }
}