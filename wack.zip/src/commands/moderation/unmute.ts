import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { Colors, EmbedBuilder, GuildMember } from 'discord.js';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
    name: 'unmute',
    description: 'Unmute an user',
  })

  export class TicketsCommand extends Command {
    public constructor(context: Command.Context, options: Command.Options) {
      super(context, {
        ...options,
      });
    }
  
    public override registerApplicationCommands(
      registry: ChatInputCommand.Registry
    ) {
      registry.registerChatInputCommand(
        (builder) =>
          builder
            .setName(this.name)
            .setDescription(this.description)
            .addUserOption((option) =>
              option
                .setName('user')
                .setDescription('User to unmute')
                .setRequired(true)
            ),
        {
          guildIds: [process.env.GUILD_ID!],
        }
      );
    }
    public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
      await interaction.deferReply({ ephemeral: true }).catch(() => {});

       // @ts-ignore
       if (!interaction.member.permissions.has("Administrator")) {
        const embed = new DJS.EmbedBuilder()
        .setAuthor({
            name: interaction.client.user!.username,
            iconURL: interaction.client.user!.displayAvatarURL(),
        })
        .setColor(DJS.Colors.Red)
        .setDescription(`You do not have permission to use this command`)
        .setTimestamp()
        
        return interaction.followUp({ embeds: [embed] })
    }

        let member = interaction.options.getMember('user')! as GuildMember;

        if (
            member.roles.highest.position >=
            (interaction.member! as GuildMember).roles.highest.position
          )
            return interaction.editReply(
              'You cannot unmute a user with a hierarchy greater than or equal to yours'
            );
      
          if (
            member.roles.highest.position >=
              (
                interaction.guild!.members.cache.get(
                  this.container.client.user!.id
                ) as GuildMember
              ).roles.highest.position ||
            !member.manageable
          )
            return interaction.editReply("I can't unmute that member");

            const embed = new EmbedBuilder({
                author:{
                  name: this.container.client.user.username,
                  iconURL: this.container.client.user.displayAvatarURL()
                },
                title: `Unmute ${member.user.username}`,
                description: `${member.user.tag} is unmute now`,
                timestamp: Date.now(),
                color: Colors.Yellow
              });

              interaction.editReply({
                embeds: [embed]
              })
              member.timeout(null)
    }
}