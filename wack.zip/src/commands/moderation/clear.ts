import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import { TextChannel, EmbedBuilder, Colors } from 'discord.js';
import DJS from 'discord.js';

@ApplyOptions<Command.Options>({
  name: 'clear',
  description: "Clear channel's messages",
})
export class TicketsCommand extends Command {
  public constructor(context: Command.Context, options: Command.Options) {
    super(context, {
      ...options,
    });
  }

  public override registerApplicationCommands(
    registry: ChatInputCommand.Registry
  ) {
    registry.registerChatInputCommand(
      (builder) =>
        builder
          .setName(this.name)
          .setDescription(this.description)
          .addIntegerOption((option) =>
            option
              .setName('amount')
              .setDescription('Amount of messages to delete')
              .setMinValue(1)
              .setRequired(true)
              .setMaxValue(99)
          ),
      {
        guildIds: [process.env.GUILD_ID!],
      }
    );
  }

  public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {

    await interaction.deferReply({ ephemeral: true }).catch(() => {});
      // @ts-ignore
      if (!interaction.member.permissions.has("Administrator")) {
      const embed = new DJS.EmbedBuilder()
      .setAuthor({
          name: interaction.client.user!.username,
          iconURL: interaction.client.user!.displayAvatarURL(),
      })
      .setColor(DJS.Colors.Red)
      .setDescription(`You do not have permission to use this command`)
      .setTimestamp()
      
      return interaction.followUp({ embeds: [embed] })
  }
    let cantidad: number = interaction.options.getInteger('amount')!;

    let err: boolean = false;

    await (interaction.channel! as TextChannel)
      .bulkDelete(cantidad + 1)
      .catch(() => {
        interaction.editReply(
          'I cannot delete messages that have been sent more than two weeks ago'
        );

        err = true;
      });

    if (err) return;

    const embed = new EmbedBuilder()
      .setColor(Colors.Green)
      .setDescription(`\`${cantidad}\` messages have been cleaned in <#${interaction.channel!.id}>`)
      .setAuthor({
        name: interaction.client.user!.username,
        iconURL: interaction.client.user.displayAvatarURL(),
      })
      .setTimestamp();

    interaction
      .channel!.send({ embeds: [embed] })
      .then((m) => setTimeout(() => m.delete(), 6000));
  }
}
