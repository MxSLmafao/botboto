import { Command, ChatInputCommand } from '@sapphire/framework';
import { ApplyOptions } from '@sapphire/decorators';
import DJS, { ButtonBuilder } from 'discord.js';

@ApplyOptions<Command.Options>({
    name: 'ban',
    description: 'Ban an user',
    })

    export class TicketsCommand extends Command {
        public constructor(context: Command.Context, options: Command.Options) {
          super(context, {
            ...options,
          });
        }

        public override registerApplicationCommands(
            registry: ChatInputCommand.Registry
          ) {
            registry.registerChatInputCommand(
              (builder) =>
                builder
                  .setName(this.name)
                  .setDescription(this.description)
                  .addUserOption((option) =>
                    option
                      .setName('user')
                      .setDescription('User to ban')
                      .setRequired(true)
                  )
                  .addStringOption((option) =>
                    option
                      .setName('reason')
                      .setDescription('Reason of the ban')
                      .setRequired(true)
                  ),
              {
                guildIds: [process.env.GUILD_ID!],
              }
            );
          }
        
        public async chatInputRun(interaction: Command.ChatInputCommandInteraction) {
            await interaction.deferReply({ ephemeral: true }).catch(() => {});
            try {
                const { options, guild } = interaction;
                // @ts-ignore
                if (!interaction.member.permissions.has("Administrator")) {
                    const embed = new DJS.EmbedBuilder()
                    .setAuthor({
                        name: interaction.client.user!.username,
                        iconURL: interaction.client.user!.displayAvatarURL(),
                    })
                    .setColor(DJS.Colors.Red)
                    .setDescription(`You do not have permission to use this command`)
                    .setTimestamp()
                    
                    return interaction.followUp({ embeds: [embed] })
                }

                const user = options.getUser('user')!;
                const reason = options.getString('reason') || 'No reason provided';

                const member = guild!.members.cache.get(user.id) as DJS.GuildMember;

                if (member.roles.highest.position >= (interaction.member! as DJS.GuildMember).roles.highest.position)
                    return interaction.followUp({
                        content: 'You cannot ban a user with a hierarchy greater than or equal to yours',
                        ephemeral: true,
                    });

                if (member.roles.highest.position >= (interaction.guild!.members.cache.get(this.container.client.user!.id) as DJS.GuildMember).roles.highest.position || !member.manageable)
                    return interaction.followUp({
                        content: "I can't ban that member",
                        ephemeral: true,
                    });
                
                const embed = new DJS.EmbedBuilder()
                    .setColor(DJS.Colors.Yellow)
                    .setAuthor({
                        name: interaction.client.user!.username,
                        iconURL: interaction.client.user!.displayAvatarURL(),
                    })
                    .setTitle(`Ban duration`)
                    .setDescription(
                        `How long do you want to ban ${member.user.username}`
                    )
                    .setTimestamp();
                
                    const row = new DJS.ActionRowBuilder<DJS.StringSelectMenuBuilder>({
                        components: [
                          new DJS.StringSelectMenuBuilder({
                            customId: 'temp:mute-time',
                            placeholder: 'No time selected',
                            max_values: 1,
                            options: [
                              {
                                label: '60 seconds',
                                value: '60000'
                              },
                              {
                                label: '5 minutes',
                                value: '300000'
                              },
                              {
                                label: '10 minutes',
                                value: '600000'
                              },
                              {
                                label: '1 hour',
                                value: '3600000'
                              },
                              {
                                label: '1 day',
                                value: '86400000'
                              },
                              {
                                label: '1 week',
                                value: '604800000'
                              },
                              {
                                label: '2 weeks',
                                value: '1209600000'
                              },
                              {
                                label: '1 month',
                                value: '2592000000'
                              },
                              {
                                label: '2 months',
                                value: '5184000000'
                              },
                              {
                                label: '3 months',
                                value: '7776000000'
                              },
                              {
                                label: '4 months',
                                value: '10368000000'
                              },
                              {
                                label: 'permanent',
                                value: 'permanent'
                              }
                            ]
                          })
                        ]
                      });

                const msg = await interaction.followUp({
                    embeds: [embed],
                    components: [row],
                    fetchReply: true,
                }) as DJS.Message;

                const collector = msg.createMessageComponentCollector({
                    filter: (i) => i.user.id === interaction.user.id,
                    time: 60000,
                    componentType: DJS.ComponentType.StringSelect,
                });

                collector.on('collect', async (i) => {
                    const time = i.values[0];
                    const timeMS = parseInt(time);

                    if(time === 'permanent') {
                      const embed1 = new DJS.EmbedBuilder()
                        .setColor(DJS.Colors.Yellow)
                        .setAuthor({
                            name: interaction.client.user!.username,
                            iconURL: interaction.client.user!.displayAvatarURL(),
                        })
                        .setTitle(`Ban ${member.user.username}`)
                        .setDescription(
                            `Are you sure you want to ban ${member.user.username} permanently?`
                        )
                        .setTimestamp();

                    const row1 = new DJS.ActionRowBuilder<ButtonBuilder>({
                        components: [
                            new DJS.ButtonBuilder()
                                .setCustomId('ban:confirm')
                                .setLabel('Ban')
                                .setStyle(DJS.ButtonStyle.Danger),
                            new DJS.ButtonBuilder()
                                .setCustomId('ban:cancel')
                                .setLabel('Cancel')
                                .setStyle(DJS.ButtonStyle.Secondary),
                        ],
                    });

                    await i.update({
                        embeds: [embed1],
                        components: [row1],
                    });

                    const collector1 = i.message.createMessageComponentCollector({
                        filter: (i) => i.user.id === interaction.user.id,
                        time: 60000,
                        componentType: DJS.ComponentType.Button,
                    });

                    collector1.on('collect', async (i) => {
                        if (i.customId === 'ban:confirm') {
                            await member.ban({ reason: reason });
                            await interaction.followUp({
                                content: `Successfully banned ${member.user.username}`,
                                ephemeral: true,
                            });
                            const embed1 = new DJS.EmbedBuilder()
                                .setColor(DJS.Colors.Yellow)
                                .setAuthor({
                                    name: interaction.client.user!.username,
                                    iconURL: interaction.client.user!.displayAvatarURL(),
                                })
                                .setTitle(`Ban ${member.user.username}`)
                                .setDescription(
                                    `${member.user.username} has been banned permanently by ${interaction.user.username}`
                                )
                            await i.update({
                                embeds: [embed1],
                                components: [],
                            });
                            await member.send(`You have been banned from ${guild!.name} permanently by ${interaction.user.username} for ${reason}`);
                        } else {
                            await interaction.followUp({
                                content: `Successfully cancelled ban`,
                                ephemeral: true,
                            });
                            const embed1 = new DJS.EmbedBuilder()
                                .setColor(DJS.Colors.Yellow)
                                .setAuthor({
                                    name: interaction.client.user!.username,
                                    iconURL: interaction.client.user!.displayAvatarURL(),
                                })
                                .setTitle(`Ban ${member.user.username}`)
                                .setDescription(
                                    `Ban has been cancelled by ${interaction.user.username}`
                                )
                            await i.update({
                                embeds: [embed1],
                                components: [],
                            });
                        }
                        collector1.stop
                    });
                    } else {

                    const embed = new DJS.EmbedBuilder()
                        .setColor(DJS.Colors.Yellow)
                        .setAuthor({
                            name: interaction.client.user!.username,
                            iconURL: interaction.client.user!.displayAvatarURL(),
                        })
                        .setTitle(`Ban ${member.user.username}`)
                        .setDescription(
                            `Are you sure you want to ban ${member.user.username} for ${timeMS}ms?`
                        )
                        .setTimestamp();

                    const row1 = new DJS.ActionRowBuilder<ButtonBuilder>({
                        components: [
                            new DJS.ButtonBuilder()
                                .setCustomId('ban:confirm')
                                .setLabel('Ban')
                                .setStyle(DJS.ButtonStyle.Danger),
                            new DJS.ButtonBuilder()
                                .setCustomId('ban:cancel')
                                .setLabel('Cancel')
                                .setStyle(DJS.ButtonStyle.Secondary),
                        ],
                    });

                    await i.update({
                        embeds: [embed],
                        components: [row1],
                    });

                    const collector1 = i.message.createMessageComponentCollector({
                        filter: (i) => i.user.id === interaction.user.id,
                        time: 60000,
                        componentType: DJS.ComponentType.Button,
                    });

                    collector1.on('collect', async (i) => {
                      //convert timeMS to days, hours, minutes, seconds
                      const seconds = Math.floor((timeMS / 1000) % 60);
                      const minutes = Math.floor((timeMS / (1000 * 60)) % 60);
                      const hours = Math.floor((timeMS / (1000 * 60 * 60)) % 24);
                      const days = Math.floor(timeMS / (1000 * 60 * 60 * 24));
                      const time1 = `${days} days, ${hours} hours, ${minutes} minutes, ${seconds} seconds`;

                        if (i.customId === 'ban:confirm') {
                            await member.ban({ reason: reason });
                            await interaction.followUp({
                                content: `Successfully banned ${member.user.username}`,
                                ephemeral: true,
                            });
                            const embed1 = new DJS.EmbedBuilder()
                                .setColor(DJS.Colors.Yellow)
                                .setAuthor({
                                    name: interaction.client.user!.username,
                                    iconURL: interaction.client.user!.displayAvatarURL(),
                                })
                                .setTitle(`Ban ${member.user.username}`)
                                .setDescription(
                                    `${member.user.username} has been banned for ${time1} by ${interaction.user.username}`
                                )
                            await i.update({
                                embeds: [embed1],
                                components: [],
                            });
                            await member.send(`You have been banned from ${guild!.name} for ${time1} by ${interaction.user.username} for ${reason}`);
                            setTimeout(async () => {
                                await guild!.members.unban(member.user.id);
                            }, timeMS);
                        } else {
                            await interaction.followUp({
                                content: `Successfully cancelled ban`,
                                ephemeral: true,
                            });
                            const embed1 = new DJS.EmbedBuilder()
                                .setColor(DJS.Colors.Yellow)
                                .setAuthor({
                                    name: interaction.client.user!.username,
                                    iconURL: interaction.client.user!.displayAvatarURL(),
                                })
                                .setTitle(`Ban ${member.user.username}`)
                                .setDescription(
                                    `Ban has been cancelled by ${interaction.user.username}`
                                )
                            await i.update({
                                embeds: [embed1],
                                components: [],
                            });
                        }
                    });
                  }
                });
            } catch (err) {
                console.log(err);
                interaction.followUp({
                    content: `An error has occurred: ${err}`,
                    ephemeral: true,
                });
            }
        }
    }
